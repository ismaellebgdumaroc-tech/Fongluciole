package com.fongluciole.registry;

import com.fongluciole.FonglucioleMod;
import com.fongluciole.entity.CorneluneEntity;
import com.fongluciole.entity.FonglucioleEntity;
import com.fongluciole.entity.RochecrapaudEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, FonglucioleMod.MODID);

    public static final RegistryObject<EntityType<FonglucioleEntity>> FONGLUCIOLE = ENTITIES.register("fongluciole",
            () -> EntityType.Builder.of(FonglucioleEntity::new, MobCategory.CREATURE)
                    .sized(0.9F, 1.5F).clientTrackingRange(8)
                    .build(new ResourceLocation(FonglucioleMod.MODID, "fongluciole").toString()));

    public static final RegistryObject<EntityType<CorneluneEntity>> CORNELUNE = ENTITIES.register("cornelune",
            () -> EntityType.Builder.of(CorneluneEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 0.6F).clientTrackingRange(8)
                    .build(new ResourceLocation(FonglucioleMod.MODID, "cornelune").toString()));

    public static final RegistryObject<EntityType<RochecrapaudEntity>> ROCHECRAPAUD = ENTITIES.register("rochecrapaud",
            () -> EntityType.Builder.of(RochecrapaudEntity::new, MobCategory.CREATURE)
                    .sized(0.9F, 0.8F).clientTrackingRange(8)
                    .build(new ResourceLocation(FonglucioleMod.MODID, "rochecrapaud").toString()));
}
