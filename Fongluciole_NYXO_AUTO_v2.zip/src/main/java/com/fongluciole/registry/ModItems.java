package com.fongluciole.registry;

import com.fongluciole.FonglucioleMod;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BowlFoodItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, FonglucioleMod.MODID);

    public static final RegistryObject<Item> SPORE = ITEMS.register("spore_lumineuse", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> POUSSIERE_LUNAIRE = ITEMS.register("poussiere_lunaire", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> ECAILLE_MOUSSUE = ITEMS.register("ecaille_moussue", () -> new Item(new Item.Properties()));

    /** Système 2 : soupe qui donne la vision nocturne (30 s) et rend le bol. */
    public static final RegistryObject<Item> SOUPE_LUMINEUSE = ITEMS.register("soupe_lumineuse",
            () -> new BowlFoodItem(new Item.Properties().stacksTo(1).food(new FoodProperties.Builder()
                    .nutrition(7).saturationMod(0.8F)
                    .effect(new MobEffectInstance(MobEffects.NIGHT_VISION, 600, 0), 1.0F)
                    .build())));

    public static final RegistryObject<Item> LANTERNE_SPORES = ITEMS.register("lanterne_spores",
            () -> new BlockItem(ModBlocks.LANTERNE_SPORES.get(), new Item.Properties()));

    public static final RegistryObject<Item> FONGLUCIOLE_SPAWN_EGG = ITEMS.register("fongluciole_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.FONGLUCIOLE, 0x4F8A6B, 0xFFD84A, new Item.Properties()));
    public static final RegistryObject<Item> CORNELUNE_SPAWN_EGG = ITEMS.register("cornelune_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.CORNELUNE, 0xE6E0F5, 0x9D8CDF, new Item.Properties()));
    public static final RegistryObject<Item> ROCHECRAPAUD_SPAWN_EGG = ITEMS.register("rochecrapaud_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.ROCHECRAPAUD, 0x7D8083, 0x5F8A46, new Item.Properties()));
}
