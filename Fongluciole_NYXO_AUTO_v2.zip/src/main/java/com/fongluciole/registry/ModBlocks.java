package com.fongluciole.registry;

import com.fongluciole.FonglucioleMod;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, FonglucioleMod.MODID);

    /** Système 1 : bloc lumineux (niveau 12). */
    public static final RegistryObject<Block> LANTERNE_SPORES = BLOCKS.register("lanterne_spores",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_YELLOW)
                    .strength(0.6F)
                    .sound(SoundType.GLASS)
                    .lightLevel(state -> 12)));
}
