package com.fongluciole.registry;

import com.fongluciole.FonglucioleMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, FonglucioleMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.fongluciole"))
                    .icon(() -> new ItemStack(ModItems.SPORE.get()))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.SPORE.get());
                        output.accept(ModItems.SOUPE_LUMINEUSE.get());
                        output.accept(ModItems.POUSSIERE_LUNAIRE.get());
                        output.accept(ModItems.ECAILLE_MOUSSUE.get());
                        output.accept(ModItems.LANTERNE_SPORES.get());
                        output.accept(ModItems.FONGLUCIOLE_SPAWN_EGG.get());
                        output.accept(ModItems.CORNELUNE_SPAWN_EGG.get());
                        output.accept(ModItems.ROCHECRAPAUD_SPAWN_EGG.get());
                    })
                    .build());
}
