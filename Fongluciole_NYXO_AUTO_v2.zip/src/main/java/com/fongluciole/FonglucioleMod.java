package com.fongluciole;

import com.fongluciole.registry.ModBlocks;
import com.fongluciole.registry.ModCreativeTabs;
import com.fongluciole.registry.ModEntities;
import com.fongluciole.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(FonglucioleMod.MODID)
public class FonglucioleMod {
    public static final String MODID = "fongluciole";

    public FonglucioleMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModCreativeTabs.TABS.register(bus);
    }
}
