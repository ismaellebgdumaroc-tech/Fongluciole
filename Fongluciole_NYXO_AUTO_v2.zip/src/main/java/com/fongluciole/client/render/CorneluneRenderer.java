package com.fongluciole.client.render;

import com.fongluciole.FonglucioleMod;
import com.fongluciole.client.model.CorneluneModel;
import com.fongluciole.entity.CorneluneEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class CorneluneRenderer extends MobRenderer<CorneluneEntity, CorneluneModel<CorneluneEntity>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(FonglucioleMod.MODID, "textures/entity/cornelune.png");

    public CorneluneRenderer(EntityRendererProvider.Context context) {
        super(context, new CorneluneModel<>(context.bakeLayer(CorneluneModel.LAYER_LOCATION)), 0.3F);
    }

    @Override
    public ResourceLocation getTextureLocation(CorneluneEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(CorneluneEntity entity, PoseStack poseStack, float partialTick) {
        if (entity.isBaby()) {
            poseStack.scale(0.55F, 0.55F, 0.55F);
        }
    }
}
