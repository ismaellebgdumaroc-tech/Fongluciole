package com.fongluciole.client.render;

import com.fongluciole.FonglucioleMod;
import com.fongluciole.client.model.RochecrapaudModel;
import com.fongluciole.entity.RochecrapaudEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class RochecrapaudRenderer extends MobRenderer<RochecrapaudEntity, RochecrapaudModel<RochecrapaudEntity>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(FonglucioleMod.MODID, "textures/entity/rochecrapaud.png");

    public RochecrapaudRenderer(EntityRendererProvider.Context context) {
        super(context, new RochecrapaudModel<>(context.bakeLayer(RochecrapaudModel.LAYER_LOCATION)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(RochecrapaudEntity entity) {
        return TEXTURE;
    }
}
