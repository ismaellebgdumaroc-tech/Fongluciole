package com.fongluciole.client.render;

import com.fongluciole.FonglucioleMod;
import com.fongluciole.client.model.FonglucioleModel;
import com.fongluciole.entity.FonglucioleEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class FonglucioleRenderer extends MobRenderer<FonglucioleEntity, FonglucioleModel<FonglucioleEntity>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(FonglucioleMod.MODID, "textures/entity/fongluciole.png");

    public FonglucioleRenderer(EntityRendererProvider.Context context) {
        super(context, new FonglucioleModel<>(context.bakeLayer(FonglucioleModel.LAYER_LOCATION)), 0.6F);
    }

    @Override
    public ResourceLocation getTextureLocation(FonglucioleEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(FonglucioleEntity entity, PoseStack poseStack, float partialTick) {
        if (entity.isBaby()) {
            poseStack.scale(0.55F, 0.55F, 0.55F);
        }
    }
}
