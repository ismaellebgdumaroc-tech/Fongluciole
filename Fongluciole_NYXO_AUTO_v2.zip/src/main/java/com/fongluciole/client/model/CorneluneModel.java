package com.fongluciole.client.model;

import com.fongluciole.FonglucioleMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/** Modèle généré à partir de la géométrie Bedrock (mêmes UV que la texture). */
public class CorneluneModel<T extends Entity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(FonglucioleMod.MODID, "cornelune"), "main");
    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart antennaLeft;
    private final ModelPart antennaRight;
    private final ModelPart wingLeft;
    private final ModelPart wingRight;

    public CorneluneModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.antennaLeft = this.body.getChild("antenna_left");
        this.antennaRight = this.body.getChild("antenna_right");
        this.wingLeft = this.body.getChild("wing_left");
        this.wingRight = this.body.getChild("wing_right");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-2F, -2F, -4F, 4F, 4F, 8F)
                .texOffs(24, 0).addBox(-2F, -2.5F, -8F, 4F, 4F, 4F),
                PartPose.offset(0F, 20F, 2F));
        PartDefinition p_antenna_left = p_body.addOrReplaceChild("antenna_left", CubeListBuilder.create()
                .texOffs(40, 0).addBox(-0.5F, -4F, -0.5F, 1F, 4F, 1F),
                PartPose.offset(1F, -2.5F, -7F));
        PartDefinition p_antenna_right = p_body.addOrReplaceChild("antenna_right", CubeListBuilder.create()
                .texOffs(40, 0).addBox(-0.5F, -4F, -0.5F, 1F, 4F, 1F),
                PartPose.offset(-1F, -2.5F, -7F));
        PartDefinition p_wing_left = p_body.addOrReplaceChild("wing_left", CubeListBuilder.create()
                .texOffs(0, 12).addBox(0F, -0.5F, -4F, 9F, 1F, 8F),
                PartPose.offset(2F, -2F, -1F));
        PartDefinition p_wing_right = p_body.addOrReplaceChild("wing_right", CubeListBuilder.create()
                .texOffs(0, 21).addBox(-9F, -0.5F, -4F, 9F, 1F, 8F),
                PartPose.offset(-2F, -2F, -1F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float f = ageInTicks * 1.8F;
        this.wingLeft.zRot = Mth.cos(f) * 0.6F;
        this.wingRight.zRot = -Mth.cos(f) * 0.6F;
        this.body.y = 20.0F + Mth.cos(f * 0.5F) * 0.8F;
        this.antennaLeft.xRot = Mth.sin(ageInTicks * 0.1F) * 0.15F;
        this.antennaRight.xRot = Mth.sin(ageInTicks * 0.1F + 1.0F) * 0.15F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
