package com.fongluciole.client.model;

import com.fongluciole.FonglucioleMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/** Modèle généré à partir de la géométrie Bedrock (mêmes UV que la texture). */
public class RochecrapaudModel<T extends Entity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(FonglucioleMod.MODID, "rochecrapaud"), "main");
    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart legFrontLeft;
    private final ModelPart legFrontRight;
    private final ModelPart legBackLeft;
    private final ModelPart legBackRight;

    public RochecrapaudModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = this.body.getChild("head");
        this.legFrontLeft = this.body.getChild("leg_front_left");
        this.legFrontRight = this.body.getChild("leg_front_right");
        this.legBackLeft = this.body.getChild("leg_back_left");
        this.legBackRight = this.body.getChild("leg_back_right");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-4F, -3F, -4F, 8F, 5F, 8F)
                .texOffs(0, 20).addBox(-3F, -4F, -2F, 6F, 1F, 6F),
                PartPose.offset(0F, 19F, 0F));
        PartDefinition p_head = p_body.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(32, 0).addBox(-3F, -2F, -5F, 6F, 4F, 5F)
                .texOffs(0, 13).addBox(-2.5F, -4F, -4F, 2F, 2F, 2F)
                .texOffs(0, 13).addBox(0.5F, -4F, -4F, 2F, 2F, 2F),
                PartPose.offset(0F, -1F, -4F));
        PartDefinition p_leg_front_left = p_body.addOrReplaceChild("leg_front_left", CubeListBuilder.create()
                .texOffs(8, 13).addBox(-1F, 0F, -1F, 2F, 3F, 2F),
                PartPose.offset(3F, 2F, -3F));
        PartDefinition p_leg_front_right = p_body.addOrReplaceChild("leg_front_right", CubeListBuilder.create()
                .texOffs(8, 13).addBox(-1F, 0F, -1F, 2F, 3F, 2F),
                PartPose.offset(-3F, 2F, -3F));
        PartDefinition p_leg_back_left = p_body.addOrReplaceChild("leg_back_left", CubeListBuilder.create()
                .texOffs(16, 13).addBox(-1.5F, 0F, -2F, 3F, 3F, 4F),
                PartPose.offset(3F, 2F, 3F));
        PartDefinition p_leg_back_right = p_body.addOrReplaceChild("leg_back_right", CubeListBuilder.create()
                .texOffs(16, 13).addBox(-1.5F, 0F, -2F, 3F, 3F, 4F),
                PartPose.offset(-3F, 2F, 3F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float swing = limbSwing * 0.8F;
        float a = Mth.cos(swing) * 0.9F * limbSwingAmount;
        float b = Mth.cos(swing + (float) Math.PI) * 0.9F * limbSwingAmount;
        this.legFrontLeft.xRot = a;
        this.legBackRight.xRot = a;
        this.legFrontRight.xRot = b;
        this.legBackLeft.xRot = b;
        this.head.yRot = netHeadYaw * ((float) Math.PI / 180.0F);
        this.head.xRot = headPitch * ((float) Math.PI / 180.0F) + Mth.sin(ageInTicks * 0.05F) * 0.05F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
