package com.fongluciole.client.model;

import com.fongluciole.FonglucioleMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/** Modèle généré à partir de la géométrie Bedrock (mêmes UV que la texture). */
public class FonglucioleModel<T extends Entity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(FonglucioleMod.MODID, "fongluciole"), "main");
    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart antennaLeft;
    private final ModelPart antennaRight;
    private final ModelPart legFrontLeft;
    private final ModelPart legFrontRight;
    private final ModelPart legBackLeft;
    private final ModelPart legBackRight;
    private final ModelPart tail;

    public FonglucioleModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = this.body.getChild("head");
        this.antennaLeft = this.head.getChild("antenna_left");
        this.antennaRight = this.head.getChild("antenna_right");
        this.legFrontLeft = this.body.getChild("leg_front_left");
        this.legFrontRight = this.body.getChild("leg_front_right");
        this.legBackLeft = this.body.getChild("leg_back_left");
        this.legBackRight = this.body.getChild("leg_back_right");
        this.tail = this.body.getChild("tail");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-5F, -4F, -7F, 10F, 8F, 14F),
                PartPose.offset(0F, 14F, 0F));
        PartDefinition p_head = p_body.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(48, 0).addBox(-4F, -6F, -8F, 8F, 8F, 8F)
                .texOffs(80, 0).addBox(-6F, -8.5F, -10F, 12F, 3F, 12F)
                .texOffs(0, 22).addBox(-4F, -11F, -8F, 8F, 3F, 8F)
                .texOffs(0, 40).addBox(-3.5F, -4.5F, -9F, 3F, 3F, 1F)
                .texOffs(0, 40).addBox(0.5F, -4.5F, -9F, 3F, 3F, 1F),
                PartPose.offset(0F, -2F, -7F));
        PartDefinition p_antenna_left = p_head.addOrReplaceChild("antenna_left", CubeListBuilder.create()
                .texOffs(100, 22).addBox(-0.5F, -6F, -0.5F, 1F, 6F, 1F)
                .texOffs(110, 22).addBox(-1F, -8F, -1F, 2F, 2F, 2F),
                PartPose.offset(2F, -11F, -3F));
        PartDefinition p_antenna_right = p_head.addOrReplaceChild("antenna_right", CubeListBuilder.create()
                .texOffs(100, 22).addBox(-0.5F, -6F, -0.5F, 1F, 6F, 1F)
                .texOffs(110, 22).addBox(-1F, -8F, -1F, 2F, 2F, 2F),
                PartPose.offset(-2F, -11F, -3F));
        PartDefinition p_leg_front_left = p_body.addOrReplaceChild("leg_front_left", CubeListBuilder.create()
                .texOffs(32, 22).addBox(-1.5F, 0F, -1.5F, 3F, 6F, 3F),
                PartPose.offset(3.2F, 4F, -4.5F));
        PartDefinition p_leg_front_right = p_body.addOrReplaceChild("leg_front_right", CubeListBuilder.create()
                .texOffs(32, 22).addBox(-1.5F, 0F, -1.5F, 3F, 6F, 3F),
                PartPose.offset(-3.2F, 4F, -4.5F));
        PartDefinition p_leg_back_left = p_body.addOrReplaceChild("leg_back_left", CubeListBuilder.create()
                .texOffs(32, 22).addBox(-1.5F, 0F, -1.5F, 3F, 6F, 3F),
                PartPose.offset(3.2F, 4F, 4.5F));
        PartDefinition p_leg_back_right = p_body.addOrReplaceChild("leg_back_right", CubeListBuilder.create()
                .texOffs(32, 22).addBox(-1.5F, 0F, -1.5F, 3F, 6F, 3F),
                PartPose.offset(-3.2F, 4F, 4.5F));
        PartDefinition p_tail = p_body.addOrReplaceChild("tail", CubeListBuilder.create()
                .texOffs(48, 22).addBox(-1.5F, -1.5F, 0F, 3F, 3F, 8F)
                .texOffs(80, 22).addBox(-2.5F, -2.5F, 8F, 5F, 5F, 5F),
                PartPose.offset(0F, 0F, 7F));
        return LayerDefinition.create(mesh, 128, 64);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float swing = limbSwing * 0.6662F;
        float a = Mth.cos(swing) * 1.1F * limbSwingAmount;
        float b = Mth.cos(swing + (float) Math.PI) * 1.1F * limbSwingAmount;
        this.legFrontLeft.xRot = a;
        this.legBackRight.xRot = a;
        this.legFrontRight.xRot = b;
        this.legBackLeft.xRot = b;
        this.head.yRot = netHeadYaw * ((float) Math.PI / 180.0F);
        this.head.xRot = headPitch * ((float) Math.PI / 180.0F);
        this.tail.yRot = Mth.sin(ageInTicks * 0.1F) * 0.25F + Mth.cos(swing) * 0.4F * limbSwingAmount;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
