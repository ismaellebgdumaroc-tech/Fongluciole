package com.fongluciole.client;

import com.fongluciole.FonglucioleMod;
import com.fongluciole.client.model.CorneluneModel;
import com.fongluciole.client.model.FonglucioleModel;
import com.fongluciole.client.model.RochecrapaudModel;
import com.fongluciole.client.render.CorneluneRenderer;
import com.fongluciole.client.render.FonglucioleRenderer;
import com.fongluciole.client.render.RochecrapaudRenderer;
import com.fongluciole.registry.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = FonglucioleMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientEvents {
    @SubscribeEvent
    public static void onLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(FonglucioleModel.LAYER_LOCATION, FonglucioleModel::createBodyLayer);
        event.registerLayerDefinition(CorneluneModel.LAYER_LOCATION, CorneluneModel::createBodyLayer);
        event.registerLayerDefinition(RochecrapaudModel.LAYER_LOCATION, RochecrapaudModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void onRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.FONGLUCIOLE.get(), FonglucioleRenderer::new);
        event.registerEntityRenderer(ModEntities.CORNELUNE.get(), CorneluneRenderer::new);
        event.registerEntityRenderer(ModEntities.ROCHECRAPAUD.get(), RochecrapaudRenderer::new);
    }
}
