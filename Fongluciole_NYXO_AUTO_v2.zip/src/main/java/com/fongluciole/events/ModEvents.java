package com.fongluciole.events;

import com.fongluciole.FonglucioleMod;
import com.fongluciole.entity.CorneluneEntity;
import com.fongluciole.entity.FonglucioleEntity;
import com.fongluciole.entity.RochecrapaudEntity;
import com.fongluciole.registry.ModEntities;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = FonglucioleMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {
    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.FONGLUCIOLE.get(), FonglucioleEntity.createAttributes().build());
        event.put(ModEntities.CORNELUNE.get(), CorneluneEntity.createAttributes().build());
        event.put(ModEntities.ROCHECRAPAUD.get(), RochecrapaudEntity.createAttributes().build());
    }

    /** Système 4 : où les mobs ont le droit d'apparaître (les biomes sont dans data/.../biome_modifier). */
    @SubscribeEvent
    public static void onSpawnPlacements(SpawnPlacementRegisterEvent event) {
        event.register(ModEntities.FONGLUCIOLE.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                FonglucioleEntity::checkSpawnRules, SpawnPlacementRegisterEvent.Operation.OR);
        event.register(ModEntities.CORNELUNE.get(), SpawnPlacements.Type.NO_RESTRICTIONS, Heightmap.Types.MOTION_BLOCKING,
                CorneluneEntity::checkSpawnRules, SpawnPlacementRegisterEvent.Operation.OR);
        event.register(ModEntities.ROCHECRAPAUD.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                RochecrapaudEntity::checkSpawnRules, SpawnPlacementRegisterEvent.Operation.OR);
    }
}
